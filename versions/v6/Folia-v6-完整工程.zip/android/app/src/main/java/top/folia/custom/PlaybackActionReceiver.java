package top.folia.custom;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PlaybackActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && intent.getAction() != null) {
            FoliaNativePlugin.emitMediaAction(intent.getAction());
        }
    }
}
